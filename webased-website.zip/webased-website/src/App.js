import './App.css';
import Header from './Components/Header'


function App() {
  return (
    <div className="App">
      <Header></Header>
    </div>
  );
}

export default App;
